# GOAL Counter — PETCH

เว็บนับถอยหลัง มีหน้า Login และตัวเลขถูกเก็บกลาง ทุกเครื่องเห็นเลขเดียวกัน

## บัญชีที่ใช้งานได้

- User: `PETCH`
- Password: `Admin`

## ฟีเจอร์

- เข้าสู่ระบบด้วยบัญชีด้านบน
- เริ่มนับจาก **15,407**
- กดลด / เพิ่ม / ตั้งค่าได้
- โหมดนับอัตโนมัติ
- ซิงค์คลาวด์ มือถือคนละเครื่องเห็นเลขเดียวกัน
- ถึง 0 ขึ้นหน้า GOAL

## อัปไฟล์ขึ้น GitHub

แทนที่ไฟล์ `index.html` ตัวเก่าด้วยไฟล์นี้ทั้งไฟล์

1. เปิดรีโป https://github.com/xenackhub/TheNumber
2. กดไฟล์ `index.html`
3. กดไอคอนดินสอ Edit
4. ลบของเก่าทั้งก้อน แล้ววางโค้ดใหม่
5. กด Commit changes

จากนั้นเปิด

`https://xenackhub.github.io/TheNumber/`

ถ้ายัง 404 ไป Settings → Pages  
เลือก Deploy from a branch, main, / (root)  
แล้วลบ Custom domain ถ้ายังมี petch.io
